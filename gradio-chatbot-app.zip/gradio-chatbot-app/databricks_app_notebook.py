# Databricks notebook source
# MAGIC %md
# MAGIC ### App using serving endpoint 
# MAGIC <img src ='./databricks_app.png'>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Simpe Gradio Chatbot
# MAGIC <img src ='./gradio_ui.png'>